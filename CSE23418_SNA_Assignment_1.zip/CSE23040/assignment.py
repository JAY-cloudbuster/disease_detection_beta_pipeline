import sys
import networkx as nx
import pandas as pd
from collections import Counter

# Use a non-interactive backend when running headlessly (e.g. from a script/CI)
show_plots = "--no-show" not in sys.argv and "--headless" not in sys.argv
if not show_plots:
    import matplotlib
    matplotlib.use("Agg")

import matplotlib.pyplot as plt

# -----------------------------------------------------------------------------
# Task 1: build the graph
# -----------------------------------------------------------------------------
# 10 nodes, kite-shaped head (A-G) plus a 3-node tail (H-I-J), matching the
# network diagram in the assignment.
NODES = list("ABCDEFGHIJ")

EDGES = [
    # upper diamond, hub at D
    ("A", "B"), ("A", "C"), ("A", "D"),
    ("B", "D"), ("B", "E"),
    ("C", "D"), ("D", "E"),
    # lower diamond
    ("A", "F"), ("B", "G"),
    ("C", "F"), ("D", "F"), ("D", "G"),
    ("E", "G"), ("F", "G"),
    # tail
    ("F", "H"), ("G", "H"),
    ("H", "I"),
    ("I", "J"),
]

G = nx.Graph()
G.add_nodes_from(NODES)
G.add_edges_from(EDGES)

# layout matching the picture
pos = {
    "A": (-1, 3), "B": (1, 3),
    "C": (-2, 2), "D": (0, 2), "E": (2, 2),
    "F": (-1, 1), "G": (1, 1),
    "H": (0, 0),
    "I": (0, -1),
    "J": (0, -2),
}

# -----------------------------------------------------------------------------
# Task 1: metrics for the original graph
# -----------------------------------------------------------------------------
degree_dict = dict(G.degree())
degree_sequence = sorted(degree_dict.values(), reverse=True)
degree_count = Counter(degree_sequence)
degree_dist = {k: v / G.number_of_nodes() for k, v in sorted(degree_count.items())}

density = nx.density(G)
local_clustering = nx.clustering(G)
global_clustering_avg = nx.average_clustering(G)
transitivity = nx.transitivity(G)

diameter = nx.diameter(G)
radius = nx.radius(G)
eccentricity = nx.eccentricity(G)

degree_centrality = nx.degree_centrality(G)
closeness_centrality = nx.closeness_centrality(G)
betweenness_centrality = nx.betweenness_centrality(G)

df_metrics = pd.DataFrame({
    "Node": NODES,
    "Degree": [degree_dict[n] for n in NODES],
    "Degree Centrality": [degree_centrality[n] for n in NODES],
    "Closeness Centrality": [closeness_centrality[n] for n in NODES],
    "Betweenness Centrality": [betweenness_centrality[n] for n in NODES],
    "Local Clustering": [local_clustering[n] for n in NODES],
    "Eccentricity": [eccentricity[n] for n in NODES],
})

top_degree_node = df_metrics.loc[df_metrics["Degree Centrality"].idxmax(), "Node"]
top_closeness_node = df_metrics.loc[df_metrics["Closeness Centrality"].idxmax(), "Node"]
top_betweenness_node = df_metrics.loc[df_metrics["Betweenness Centrality"].idxmax(), "Node"]

# -----------------------------------------------------------------------------
# Drawing helper
# -----------------------------------------------------------------------------
def plot_and_save(graph, title, filename, highlighted=None):
    fig, ax = plt.subplots(figsize=(8, 7))
    node_list = sorted(graph.nodes())

    colors = ["#e74c3c" if n == highlighted else "#3498db" for n in node_list]

    nx.draw_networkx(
        graph, pos=pos, ax=ax,
        nodelist=node_list,
        node_color=colors, node_size=900,
        font_color="white", font_size=11, font_weight="bold",
        edge_color="#7f8c8d", width=2.0, with_labels=True,
    )

    ax.set_title(title, fontsize=14, fontweight="bold", pad=20)
    ax.axis("off")
    plt.tight_layout()
    plt.savefig(filename, dpi=150, bbox_inches="tight")
    plt.show() if show_plots else plt.close()


plot_and_save(G, "Task 1 - Original Network", "original_network.png")

# -----------------------------------------------------------------------------
# Task 2: remove an influential node and recompute everything
# -----------------------------------------------------------------------------
def compute_removed_metrics(removed_node):
    G_rem = G.copy()
    G_rem.remove_node(removed_node)

    connected_rem = nx.is_connected(G_rem)
    component = G_rem if connected_rem else G_rem.subgraph(max(nx.connected_components(G_rem), key=len))

    return {
        "Connected": connected_rem,
        "Density": nx.density(G_rem),
        "Clustering": nx.average_clustering(G_rem),
        "Diameter": nx.diameter(component),
        "Radius": nx.radius(component),
    }


metrics_rem_D = compute_removed_metrics("D")
metrics_rem_H = compute_removed_metrics("H")
metrics_rem_F = compute_removed_metrics("F")

plot_and_save(G.subgraph([n for n in NODES if n != "D"]), "Task 2 - Node D removed", "removed_node_D.png")
plot_and_save(G.subgraph([n for n in NODES if n != "H"]), "Task 2 - Node H removed", "removed_node_H.png")
plot_and_save(G.subgraph([n for n in NODES if n != "F"]), "Task 2 - Node F removed", "removed_node_F.png")

# -----------------------------------------------------------------------------
# Console report
# -----------------------------------------------------------------------------
print("Social Network Analysis - Assignment 1")
print("=" * 50)

print(f"\nNodes: {G.number_of_nodes()}   Edges: {G.number_of_edges()}   Connected: {nx.is_connected(G)}")
print(f"Density: {density:.4f}   Diameter: {diameter}   Radius: {radius}")

print("\nDegree distribution (degree -> fraction of nodes):")
for k, v in degree_dist.items():
    print(f"  {k}: {v:.4f}")

print("\nPer-node metrics:")
print(df_metrics.to_string(index=False, formatters={
    "Degree Centrality": "{:.4f}".format,
    "Closeness Centrality": "{:.4f}".format,
    "Betweenness Centrality": "{:.4f}".format,
    "Local Clustering": "{:.4f}".format,
}))

print("\nMost influential node by each measure:")
print(f"  Highest Degree Centrality      : {top_degree_node} ({degree_centrality[top_degree_node]:.4f})")
print(f"  Highest Closeness Centrality   : {top_closeness_node} ({closeness_centrality[top_closeness_node]:.4f})")
print(f"  Highest Betweenness Centrality : {top_betweenness_node} ({betweenness_centrality[top_betweenness_node]:.4f})")

print("\nImpact of removing each high-influence node:")
df_removal = pd.DataFrame({
    "Removal case": ["Original", "Remove D (degree hub)", "Remove H (betweenness bridge)", "Remove F (closeness leader)"],
    "Connected": [True, metrics_rem_D["Connected"], metrics_rem_H["Connected"], metrics_rem_F["Connected"]],
    "Density": [density, metrics_rem_D["Density"], metrics_rem_H["Density"], metrics_rem_F["Density"]],
    "Avg Clustering": [global_clustering_avg, metrics_rem_D["Clustering"], metrics_rem_H["Clustering"], metrics_rem_F["Clustering"]],
    "Diameter": [diameter, metrics_rem_D["Diameter"], metrics_rem_H["Diameter"], metrics_rem_F["Diameter"]],
    "Radius": [radius, metrics_rem_D["Radius"], metrics_rem_H["Radius"], metrics_rem_F["Radius"]],
})
print(df_removal.to_string(index=False, formatters={
    "Density": "{:.4f}".format,
    "Avg Clustering": "{:.4f}".format,
}))
print("(Note: removing H disconnects the tail, so its diameter/radius are for the largest remaining component.)")

print("\nFigures saved: original_network.png, removed_node_D.png, removed_node_H.png, removed_node_F.png")

# -----------------------------------------------------------------------------
# Written report
# -----------------------------------------------------------------------------
report = f"""# Social Network Analysis - Assignment 1

## Task 1: Network graph and metrics

The network has 10 nodes (A-J) and {G.number_of_edges()} edges: a densely connected
"kite" of nodes A-G built around a hub (D), plus a 3-node tail (H, I, J)
hanging off the kite.

- Density: {density:.4f}
- Diameter: {diameter}
- Radius: {radius}
- Global clustering coefficient (average): {global_clustering_avg:.4f}
- Transitivity: {transitivity:.4f}

### Per-node metrics

| Node | Degree | Degree Centrality | Closeness Centrality | Betweenness Centrality | Local Clustering | Eccentricity |
| :--: | :----: | :----------------: | :-------------------: | :---------------------: | :---------------: | :----------: |
"""

for _, row in df_metrics.iterrows():
    report += (
        f"| {row['Node']} | {int(row['Degree'])} | {row['Degree Centrality']:.4f} | "
        f"{row['Closeness Centrality']:.4f} | {row['Betweenness Centrality']:.4f} | "
        f"{row['Local Clustering']:.4f} | {int(row['Eccentricity'])} |\n"
    )

report += f"""
### Most influential node by each measure

- Highest Degree Centrality: **{top_degree_node}** ({degree_centrality[top_degree_node]:.4f}) - the most direct
  neighbors, i.e. the local hub of the kite.
- Highest Closeness Centrality: **{top_closeness_node}** ({closeness_centrality[top_closeness_node]:.4f}) - shortest
  average distance to every other node, so it can reach the whole network fastest.
- Highest Betweenness Centrality: **{top_betweenness_node}** ({betweenness_centrality[top_betweenness_node]:.4f}) - sits
  on the most shortest paths between other pairs, acting as a broker between the kite and the tail.

## Comparing the three centrality measures

Each measure captures a different notion of "importance":

1. **Degree centrality (local reach):** node D has the most direct connections and represents a local hub
   in the dense head of the network. It's the best-placed node for spreading something to its immediate
   neighbors in a single step.
2. **Closeness centrality (global efficiency):** the node(s) with the shortest average distance to
   everyone else are best placed to reach or be reached by the whole network quickly, since they sit
   near the "middle" of the kite/tail structure.
3. **Betweenness centrality (brokerage):** node H has by far the highest betweenness despite a modest
   degree, because every path between the kite (A-G) and the tail (I, J) has to pass through it. It is
   a structural bridge/gatekeeper rather than a popular hub.

The fact that different nodes top different measures shows that "importance" in a network is
multi-dimensional: a hub is not necessarily a broker, and a broker is not necessarily the most
efficiently positioned node.

## Task 2: removing the most influential node and re-measuring

We remove each of the three high-influence nodes in turn and recompute the metrics.

| Removal case | Connected | Density | Avg Clustering | Diameter | Radius |
| :--- | :--: | :--: | :--: | :--: | :--: |
| Original | Yes | {density:.4f} | {global_clustering_avg:.4f} | {diameter} | {radius} |
| Remove D (degree hub) | Yes | {metrics_rem_D['Density']:.4f} | {metrics_rem_D['Clustering']:.4f} | {metrics_rem_D['Diameter']} | {metrics_rem_D['Radius']} |
| Remove H (betweenness bridge) | No | {metrics_rem_H['Density']:.4f} | {metrics_rem_H['Clustering']:.4f} | {metrics_rem_H['Diameter']}* | {metrics_rem_H['Radius']}* |
| Remove F (closeness leader) | Yes | {metrics_rem_F['Density']:.4f} | {metrics_rem_F['Clustering']:.4f} | {metrics_rem_F['Diameter']} | {metrics_rem_F['Radius']} |

*For the H removal, the network splits in two; diameter/radius are reported for the larger remaining component.

### Why did the diameter change?

- **Removing D:** diameter stayed at {diameter}. D sits in a redundant part of the graph - there are
  still alternative paths (through the other kite nodes) between any pair of nodes, so losing D doesn't
  push the longest shortest path any further.
- **Removing H:** the network fragments into the kite (A-G) and the rest of the tail. The global
  diameter is technically undefined once the graph is disconnected; within the surviving kite component
  it actually shrinks, since the long detour out to the tail is gone.
- **Removing F:** the diameter increases from {diameter} to {metrics_rem_F['Diameter']}. F was a shortcut
  between part of the kite and the tail; without it, some pairs need a longer detour through D and G to
  reach H, I, and J.

### Why did clustering change?

- **Removing D:** average clustering drops, because D belonged to several triangles in the densely
  connected kite - removing it destroys those triangles.
- **Removing H:** average clustering rises slightly. H's own local clustering coefficient was low (its
  neighbors F, G, I are not well connected to each other), so removing a low-clustering node raises the
  network-wide average.
- **Removing F:** clustering also drops, since F was part of several triangles in the kite.

### What this says about robustness

- The network is fragile to attacks on **bridge** nodes (high betweenness, like H): removing a single
  bridge disconnects the tail entirely.
- It is comparatively **robust** to losing a pure **hub** (high degree, like D), because the kite region
  has enough redundant connections to stay connected and keep path lengths short.
- Losing a **closeness leader** (like F) doesn't disconnect anything, but it does hurt efficiency -
  paths get longer, so information takes more steps to travel across the network.

Overall, degree centrality alone is a poor proxy for how much damage removing a node will do; the
bridge/broker nodes identified by betweenness centrality are the ones whose loss is most damaging to
the network's structure.
"""

with open("Assignment1_Report.md", "w", encoding="utf-8") as f:
    f.write(report)

print("Report written to Assignment1_Report.md")
